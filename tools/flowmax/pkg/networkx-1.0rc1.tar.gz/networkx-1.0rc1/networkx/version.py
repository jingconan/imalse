"""
Version information for NetworkX, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.0rc1'
__revision__ = 'None'
__date__ = 'Sun Aug 16 16:27:52 2009'

