.. _linalg:


Linear Algebra
**************

.. currentmodule:: networkx

Spectrum
---------

.. autosummary::
   :toctree: generated/

   adj_matrix
   laplacian
   normalized_laplacian
   laplacian_spectrum
   adjacency_spectrum
