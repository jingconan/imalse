.. _glossary:

Glossary
========

.. glossary::

   edge
	FIXME

   hashable
	FIXME	

   nbunch
	FIXME

   node
	FIXME	