********
Matching
********

.. automodule:: networkx.algorithms.matching
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   max_weight_matching

