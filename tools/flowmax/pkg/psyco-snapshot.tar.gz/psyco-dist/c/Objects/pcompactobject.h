 /***************************************************************/
/***              Meta-version of compactobject.h              ***/
 /***************************************************************/

#ifndef _PSY_COMPACTOBJECT_H
#define _PSY_COMPACTOBJECT_H


#include "pobject.h"
#include "pabstract.h"


/***************************************************************/
 /* virtual compact objects.                                    */
/*EXTERNFN vinfo_t* PsycoCompact_New(PsycoObject* po);
  XXX to do */

#endif /* _PSY_COMPACTOBJECT_H */
