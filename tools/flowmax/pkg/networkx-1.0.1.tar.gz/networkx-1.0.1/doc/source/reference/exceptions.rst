**********
Exceptions
**********

.. automodule:: networkx.exception
.. currentmodule:: networkx

.. autoclass:: networkx.NetworkXException

.. autoclass:: networkx.NetworkXError



