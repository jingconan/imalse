***********
API changes
***********

.. toctree::
   :maxdepth: 2

   api_1.0
   api_0.99
