GML
===
.. automodule:: networkx.readwrite.gml
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   read_gml
   write_gml
   parse_gml

