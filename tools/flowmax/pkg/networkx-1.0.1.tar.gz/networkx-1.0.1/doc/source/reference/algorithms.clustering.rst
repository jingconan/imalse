**********
Clustering
**********

.. automodule:: networkx.algorithms.cluster
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   triangles
   transitivity
   clustering
   average_clustering   
