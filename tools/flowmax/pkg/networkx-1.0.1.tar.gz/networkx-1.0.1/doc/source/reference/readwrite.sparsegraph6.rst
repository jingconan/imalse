SparseGraph6 
============
.. automodule:: networkx.readwrite.sparsegraph6
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   read_graph6
   parse_graph6
   read_graph6_list
   read_sparse6
   parse_sparse6
   read_sparse6_list


