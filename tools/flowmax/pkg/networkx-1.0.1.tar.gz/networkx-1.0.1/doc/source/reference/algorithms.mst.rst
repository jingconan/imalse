*********************
Minimum Spanning Tree
*********************

.. automodule:: networkx.algorithms.mst

.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   mst
