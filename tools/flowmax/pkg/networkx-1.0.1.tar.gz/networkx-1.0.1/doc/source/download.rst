--------
Download
--------

Source and binary releases
~~~~~~~~~~~~~~~~~~~~~~~~~~
http://cheeseshop.python.org/pypi/networkx/

http://networkx.lanl.gov/download/networkx/

Subversion source code repository
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*Anonymous*          

svn checkout http://networkx.lanl.gov/svn/networkx/trunk networkx

*Authenticated* 

svn checkout https://networkx.lanl.gov/svn/networkx/trunk networkx


Documentation
~~~~~~~~~~~~~
*PDF*

http://networkx.lanl.gov/networkx.pdf

*HTML in zip file*

http://networkx.lanl.gov/networkx-documentation.zip
