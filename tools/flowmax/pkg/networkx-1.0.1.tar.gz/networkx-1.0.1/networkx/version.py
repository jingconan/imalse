"""
Version information for NetworkX, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.0.1'
__revision__ = None
__date__ = 'Mon Jan 11 13:23:33 2010'

